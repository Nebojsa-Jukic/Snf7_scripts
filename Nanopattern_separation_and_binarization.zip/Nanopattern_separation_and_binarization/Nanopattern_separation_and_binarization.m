% This code was developed in the Scheuring lab (Weill Cornell Medicine, New
% York, USA) for the analysis of High-Speed Atomic Force Microscopy data of
% the ESCRT-III protein Snf7 polymerizing on a nanopatterned, supported
% lipid bilayer-covered HS-AFM support. When using this code, please cite
% the following:

% INSTRUCTIONS AND NOTES:
% The code necessitates one file to be loaded to work: an aligned
% and cropped HS-AFM frame stack converted into a readable .tif format.
% The prerequisite image processing was carried out using ImageJ.
% If using a different file than the one used in the publication,
% please consider that some of the parameters of the input files are
% hard-coded (e.g. HS-AFM stack dimensions, pixel-to-nanometer ratio, etc.)
% and will have to be manually altered for the code to work.

clearvars -except infopol pol temp

[fname,fpath] = uigetfile('*.tif');
wholepath = strcat(fpath,fname);

sz = 257;

if exist('pol','var') == 0
    infopol = imfinfo(wholepath);
        for i = 1:size(infopol,1)
            temp = imread(wholepath,i);
            pol(:,:,i) = temp(1:sz,1:sz);
        end
    pol = imresize(pol,2,'bilinear');
    sz = sz*2;
else
    sz = sz*2;
end

selpath = uigetdir(fpath,'Choose destination folder')
cd(selpath)
noext = char(fname);
formatOut = 'yyyymmdd-tHHMMss';
timestmp = datestr(now,formatOut);
dirname = strcat(noext(1:end-4),'_',timestmp);
[status,msg] = mkdir('Analysis\Figures\Newbin',dirname);
cd(strcat('Analysis\Figures\Newbin\',dirname));

usewhat = pol(1:sz,1:sz,:);
usewhat(:,:,[113 114 122 123 132 133 142])=[];
polbadframesout = usewhat;

numremain = size(pol,3)-size(polbadframesout,3);

% per-frame median subraction
for i = 1:size(usewhat,3)
keepmedian(i) = median(usewhat(:,:,i),'all');
usewhat(:,:,i) = usewhat(:,:,i)-keepmedian(i);
end

whi3 = zeros(1,size(infopol,1)-numremain);
whi3(1:36) = 90;
whi3(37:107) = linspace(90,0,71);
whi3 = round(whi3/150,2); 
globaloffset = 0.4;

sensitivity_setting = 2;
kernel_size = [11 11 5];
Ttmp = imgaussfilt3(usewhat,kernel_size);
keepparams = zeros(size(infopol,1)-numremain,2);

%the kernel size makes a lot of difference; increasing the kernel size in
%the first and second dimension results in thicker filament being detected;
%increasing it in the third dimension means there is more contribution from
%previous and subsequent frames.


%% binarization

clear keepf2vect

h_adjustment = 0; % this value is best kept at 0 because it can either
% disproportionatelly and non-selectively enhance or decrease the
% binarization of the slopes of the bumps

bw  = zeros(sz,sz,size(infopol,1)-numremain);

for i = 1:size(infopol,1)-numremain

% in order to rescale, we will take the minimum and maximum of each frame
frame_min(i) = min(min(usewhat(:,:,i)));
frame_max(i) = max(max(usewhat(:,:,i)));
subst_channel(:,:,i) = rescale(Ttmp(:,:,i),frame_min(i)+h_adjustment,frame_max(i)-h_adjustment);
% subst_channel(:,:,i) = rescale(Ttmp(:,:,i),frame_min(i),frame_max(i)-h_adjustment);
prot_channel(:,:,i) = usewhat(:,:,i)-subst_channel(:,:,i);

clear linearall
clear linearcdatag linearcdatar origindx keeplinearcdatag f2vect1

end

fine_corrug = mean(prot_channel(:,:,1:30),3);
prot_channel_fine = prot_channel - imgaussfilt(fine_corrug,[5 5]);
subst_channel_reference = mean(subst_channel(:,:,1:30),3);
linearsubstratereference = double(subst_channel_reference(:)');

for i = 1:size(infopol,1)-numremain

pixelnumber = size(usewhat,1)*size(usewhat,2);
pixelindex = pixelnumber*(i-1)+1:1:pixelnumber*i;

for n = 1:pixelnumber
% linearsubstrateadjusted(n) = double(subst_channel_adjust(pixelindex(n)));
linearsubstrate(n) = double(subst_channel(pixelindex(n)));
linearproteinchannel(n) = double(prot_channel_fine(pixelindex(n)));
origindx(n) = pixelindex(n);
end

linearall = cat(1,linearsubstrate,linearproteinchannel,origindx);

% concatenate vectors of adjusted substrate channel, linearproteinchannel,
% and original pixel index in array (for trackability of proper indexing)

linearall = linearall';
linearall = sortrows(linearall,1); % sort ALL rows in linearall by the first column
% and that is the vector representation of the adjusted substrate channel
keeplinearall{i,:} = linearall'; % keep for trackability
f2 = fit([1:pixelnumber]',linearall(:,2),'poly1'); % linear fit of the second column in linearall;
% that is the protein channel that we're applying a linear fit to
keepparams(i,1)=f2.p1; % keep slope
keepparams(i,2)=f2.p2; % keep y-intercept
f2vect1 = f2.p1*(1:pixelnumber)+f2.p2; % make vector of same length as each frame;
keepf2vect(i,:) = f2vect1; % keep these vectors for trackability; each row is the linear fit to one frame's protein channel
offset(i) = whi3(i)+globaloffset; 
% the offset is important because the early frames in the movie have no protein;
% the binarization in frames 1 to cca 40 thus yield binarization of
% small-scale surface roughness, which is unwanted. This global offset is
% set manually for the whole movie and never changes, unlike the offset
% component defined by linear fit to the protein channel, which is
% different for each frame
[findex{i}] = find(linearall(:,2)'>f2vect1+offset(i));
% find all pixels which have an intensity in the protein channel that are
% above the threshold
bw(keeplinearall{i,1}(3,findex{i})) = 1;
% set these pixels to be 1
nones(i)=nnz(bw(:,:,i));
% count number of non-zeros (ones) in each frame
end

%% occupancy by height
heightmap = double(mean(Ttmp(:,:,1:30),3)-min(min(mean(Ttmp(:,:,1:30),3))));
height_plus_binary = cat(3,heightmap,bw);
height_plus_binary_linearized = reshape(height_plus_binary,size(heightmap,1)^2,size(usewhat,3)+1);
height_plus_binary_linearized_sorted = sortrows(height_plus_binary_linearized,1);


%% slope calculation and occupancy by slope
sample = double(mean(Ttmp(:,:,1:30),3));

slope = imgradient(sample);
slope_plus_binary = cat(3,slope,bw);
slope_plus_binary_linearized = reshape(slope_plus_binary,size(slope,1)^2,size(usewhat,3)+1);
slope_plus_binary_linearized_sorted = sortrows(slope_plus_binary_linearized,1);

%% curvature calculation and occupancy by curvature
% ksizeprompt = 'Define curvature calculation kernel size?'
% kersizcur = input(ksizeprompt);
kersizcur = 31;
% Define lower and upper boundaries of the area to be considered (avoid
% edge effects)
lower = ceil(kersizcur/2);
upper1 = size(sample,1)-round(kersizcur/2);
upper2 = size(sample,2)-round(kersizcur/2);
[columnsinkernel,rowsinkernel] = meshgrid(1:kersizcur,1:kersizcur);
circlePixels = (rowsinkernel-round(kersizcur/2)).^2 + (columnsinkernel-round(kersizcur/2)).^2 <= (round(kersizcur/2)-1)^2;
ring = double(bwmorph(circlePixels,'remove'));


for i=lower:upper1
    for j=lower:upper2
%         [indout] = sub2ind([size(resstack,1) size(resstack,2)],i,j);
        kwindow = sample((i-round(kersizcur/2)+1):(i+ceil(kersizcur/2)-1),(j-round(kersizcur/2)+1):(j+ceil(kersizcur/2)-1));
        kwindow1 = kwindow.*ring;
        cap = mean(kwindow1(kwindow1~=0))-kwindow(round(kersizcur/2),round(kersizcur/2));
        curvature(i,j) = 1/(((cap^2)+round(kersizcur/2)^2)/(2*cap));
    end
end

curvature_cutborder = curvature(ceil(kersizcur/2):end,ceil(kersizcur/2):end);
binary_cutborder = bw(ceil(kersizcur/2):end-ceil(kersizcur/2),ceil(kersizcur/2):end-ceil(kersizcur/2),:);
curcut_plus_bincut = cat(3,curvature_cutborder,binary_cutborder);
curcut_plus_bincut_linearized = reshape(curcut_plus_bincut,size(curvature_cutborder,1)^2,size(usewhat,3)+1);
curcut_plus_bincut_linearized_sorted = sortrows(curcut_plus_bincut_linearized,1);

%% outputs

textID = fopen(strcat(dirname,'_note.txt'),'w');
fprintf(textID, 'Binarization of ');
fprintf(textID, '%s \n\n', wholepath);
fprintf(textID, 'Code used: ');
fprintf(textID, '%s \n\n', mfilename);
fprintf(textID, 'Parameters for ');
fprintf(textID, '%s \n\n', dirname);
fprintf(textID, 'Size of original movie:\n\n');
fprintf(textID, '%d %d \n\n', size(temp));
fprintf(textID, 'Length of original movie:\n\n');
fprintf(textID, '%d \n\n', size(infopol,1));
fprintf(textID, 'Size of upsampled data (bilinear interpolation):\n\n');
fprintf(textID, '%d %d \n\n', size(pol,1:2));
fprintf(textID, 'Frames excluded:\n\n');
fprintf(textID, '%d ', [113 114 122 123 132 133 142]);
fprintf(textID, '\n\nOffset (manual, due to difference in median):\n\n');
fprintf(textID, '%4.2f ', whi3);
fprintf(textID, '\n\nSensitivity setting for adaptive thresholding algorithm:\n\n');
fprintf(textID, '%3.1f \n', sensitivity_setting);
fprintf(textID, '\n\nKernel size for adaptive thresholding algorithm:\n\n');
fprintf(textID, '%d %d %d \n\n', kernel_size);
fprintf(textID, 'Global offset (binarization sensitivity):\n\n');
fprintf(textID, '%3.2f \n\n', globaloffset);
fprintf(textID, 'Height adjustment (when rescaling Gaussian to real height):\n\n');
fprintf(textID, '%3.1f \n', h_adjustment);
fprintf(textID, 'Curvature calculation sample: mean(Ttmp(1:30))\n\n');
fprintf(textID, 'kersizcur:\n\n');
fprintf(textID, '%d \n', kersizcur);
fclose(textID)

figure()
imagesc(bw(:,:,222))
hold on
title(strcat('binarized frame 222'))
colormap gray
daspect([1 1 1])
print('-dsvg',strcat('binarized frame 222 with offset point',num2str(globaloffset*10)))
close all

figure()
plot(nones/514^2)
hold on
title(strcat('global offset ',num2str(globaloffset)))
plot(smooth(nones/514^2,10))
ax = gca;
ax.YLim = [0 0.6];
print('-dsvg',strcat('global offset point ', num2str(globaloffset*10), ' nones'))
close all

figure()
imshowpair(mean(prot_channel(:,:,218:227),3),mean(bw(:,:,218:227),3),'montage')
hold on
title(strcat('10 frame reconstruction from binarization with ',num2str(globaloffset),' offset'))
print('-dsvg',strcat('10 frame reconstruction from binarization with point ',num2str(globaloffset*10),' offset'))
close all

figure()
imshowpair(mean(prot_channel(:,:,218:227),3),mean(bw(:,:,218:227),3),'montage')
hold on
title(strcat('10 frame reconstruction from binarization with ',num2str(globaloffset),' offset'))
print('-dpng',strcat('10 frame reconstruction from binarization with point ',num2str(globaloffset*10),' offset'))
close all

figure()
imagesc(curvature_cutborder)
daspect([1 1 1])
colormap jet
hold on
title('Calculated surface curvature')
print('-dpng',strcat('Calculated surface curvature; kernel_size', num2str(kernel_size),' and kersizcur ', num2str(kersizcur)));
close all

figure()
imagesc(heightmap)
daspect([1 1 1])
colormap parula
hold on
title('Reference heightmap')
print('-dpng',strcat('Height map; kernel_size', num2str(kernel_size)));
close all

figure()
imagesc(slope)
daspect([1 1 1])
colormap bone
hold on
title('Calculated surface slope')
print('-dpng',strcat('Calculated surface slope; kernel_size', num2str(kernel_size),' and kersizcur ', num2str(kersizcur)));
close all

figure()
imagesc(height_plus_binary_linearized_sorted(:,2:end))
colormap gray
hold on
title('Occupancy plot; sorted by height')
print('-dsvg','Occupancy as function of height and time')
print('-dpng','Occupancy as function of height and time')
close all

figure()
imagesc(slope_plus_binary_linearized_sorted(:,2:end))
colormap gray
hold on
title('Occupancy plot; sorted by slope')
print('-dsvg','Occupancy as function of slope and time')
print('-dpng','Occupancy as function of slope and time')
close all

figure()
imagesc(curcut_plus_bincut_linearized_sorted(:,2:end))
colormap gray
hold on
title('Occupancy plot; sorted by curvature')
print('-dsvg','Occupancy as function of curvature and time')
print('-dpng','Occupancy as function of curvature and time')
close all

for i = [44,49,66,105,158,229]
figure()
imagesc(imfuse(prot_channel(:,:,i)-mean(prot_channel(:,:,1:30),3),zeros(514,514),'falsecolor','Scaling','independent','ColorChannels',[1 2 1]));
daspect([1 1 1])
print('-dsvg',strcat('prot_channel_frame',num2str(i)))
print('-dpng',strcat('prot_channel_frame',num2str(i)))
end
close all
 
for i = [44,49,66,105,158,229]
figure()
imagesc(bw(:,:,i));
colormap gray
daspect([1 1 1])
print('-dsvg',strcat('bw_frame',num2str(i)))
print('-dpng',strcat('bw_frame',num2str(i)))
end
close all

% reference frame surface characteristics: height, slope, curvature

heightbinsize = 0.25;
sample = sample - min(min(sample));
heightbinlims2 = [round(min(min(sample))):heightbinsize:(floor(max(max(sample))/heightbinsize)+1)*heightbinsize];
for i = 1:numel(heightbinlims2)-1
pwlh(i,:) = [heightbinlims2(i) heightbinlims2(i+1)];
end
pwlh(i,2)=Inf;
figurecontourhght = figure()
cmap = parula(size(pwlh,1)) ;
%Arrange the colors range
colors = zeros(size(sample));
for i = 1:size(pwlh,1)
colors(sample > pwlh(i,1) & sample<=pwlh(i,2)) = pwlh(i,2);
end
[~,hcf] = contourf(sample,heightbinlims2)
set(hcf,'LineColor','none')
daspect([1 1 1])
ax = gca;
ax.XTick = [];
ax.YTick = [];
axis tight
colormap(cmap);
hH = colorbar
caxis([0 35])
hH.Ticks = [0:5:35];
print('Figurehghtcontour','-dsvg')
heighthist = histogram(sample,'BinWidth',heightbinsize);
hcnts = heighthist.Values;
figureheightbinhist = figure()
b = barh(1:size(hcnts,2),hcnts,'FaceColor','flat','BarWidth',1)
b.CData = cmap;
print('Figureheightbins','-dsvg')

clear slopebinlims2 pwls colors scf hS slopehist scnts

slopebinsize = 0.05;
slopebinlims2 = [round(min(min(slope))):slopebinsize:(floor(max(max(slope))/slopebinsize)+1)*slopebinsize];
for i = 1:numel(slopebinlims2)-1
pwls(i,:) = [slopebinlims2(i) slopebinlims2(i+1)];
end
pwls(i,2)=Inf;
figurecontourslope = figure()
cmap = bone(size(pwls,1)) ;
%Arrange the colors range
colors = zeros(size(slope));
for i = 1:size(pwls,1)
colors(slope > pwls(i,1) & slope<=pwls(i,2)) = pwls(i,2);
end
[~,scf] = contourf(slope,slopebinlims2)
set(scf,'LineColor','none')
daspect([1 1 1])
ax = gca;
ax.XTick = [];
ax.YTick = [];
axis tight
colormap(cmap);
hS = colorbar
caxis([0 pwls(end,1)+slopebinsize])
hS.Ticks = [0:1:pwls(end,1)+slopebinsize];
print('Figureslopecontour','-dsvg')
figureslopebins = figure()
slopehist = histogram(slope,'BinWidth',slopebinsize);
scnts = slopehist.Values;
bS = barh(1:size(scnts,2),scnts,'FaceColor','flat','BarWidth',1)
bS.CData = cmap;
ax = gca;
ax.YTick = [];
colormap(cmap);
hS = colorbar
caxis([0 pwls(end,1)+slopebinsize])
hS.Ticks = [0:1:pwls(end,1)+slopebinsize];
print('Figureslopebins','-dsvg')

clear pwlc curvaturebinlims2 colors ccnts

curvaturebinsize = 0.0003;
curvaturebinlims2 = [round(min(min(curvature_cutborder)),4)-curvaturebinsize:curvaturebinsize:(floor(max(max(curvature_cutborder))/curvaturebinsize)+1)*curvaturebinsize];
for i = 1:numel(curvaturebinlims2)-1
pwlc(i,:) = [curvaturebinlims2(i) curvaturebinlims2(i+1)];
end
pwlc(i,2)=Inf;
figurecontourcurvature = figure()
cmap = jet(size(pwlc,1)) ;
%Arrange the colors range
colors = zeros(size(curvature_cutborder));
for i = 1:size(pwlc,1)
colors(curvature_cutborder > pwlc(i,1) & curvature_cutborder<=pwlc(i,2)) = pwlc(i,2);
end
[~,ccf] = contourf(curvature_cutborder,curvaturebinlims2)
set(ccf,'LineColor','none')
daspect([1 1 1])
ax = gca;
ax.XTick = [];
ax.YTick = [];
axis tight
colormap(cmap);
hC = colorbar
caxis([pwlc(1,1) pwlc(end,1)+curvaturebinsize])
%hC.Ticks = [0:1:pwlc(end,1)+curvaturebinsize];
print('Figurecurvaturecontour','-dsvg')
figurecurvaturebins = figure()
curvaturehist = histogram(curvature_cutborder,'BinWidth',curvaturebinsize);
ccnts = curvaturehist.Values;
bC = barh(1:size(ccnts,2),ccnts,'FaceColor','flat','BarWidth',1)
bC.CData = cmap;
ax = gca;
ax.YTick = [];
colormap(cmap);
hC = colorbar
caxis([pwlc(1,1) pwlc(end,1)+curvaturebinsize])
print('Figurecurvaturebins','-dsvg')
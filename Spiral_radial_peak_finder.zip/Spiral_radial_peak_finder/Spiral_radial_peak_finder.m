% This code was developed in the Scheuring lab (Weill Cornell Medicine, New
% York, USA) for the analysis of High-Speed Atomic Force Microscopy data of
% stability of mature Snf7 assemblies on a nanopatterned, supported
% lipid bilayer-covered HS-AFM support. When using this code, please cite
% the following:

% INSTRUCTIONS AND NOTES:
% The code necessitates three files to be loaded to work: 1) the aligned
% and cropped HS-AFM data converted into a readable .tif format, 2) the
% same movie, bandpass-filtered and LoG-filtered, which will be the primary
% input for the radial profile scanning section of the code, and 3) a
% logical mask to ignore the partial spirals found at the corners of the
% code. The prerequisite image processing was carried out using ImageJ.
% Usage of this code in the format provided here necessitates all
% these inputs. If using a different file, please consider that some of the
% parameters of the input files are hard-coded (e.g. spiral center position -
% manually selected, movie dimensions, etc.) and will need to be changed
% manually in order for the code to work.

% 1st file to load: aligned and cropped raw data in .tif format

[fname,fpath] = uigetfile('*.tif','Select aligned and cropped raw data file in .tif format');
wholepath = strcat(fpath,fname);

% 2nd file to load: bandpass- and LoG-filtered data in .tif format

[fname,fpath] = uigetfile('*.tif','Select bandpass- and LoG-filtered file in .tif format');
wholepathtreated = strcat(fpath,fname);

cd(fpath)
load(strcat(fpath,'\mask23.mat'));
noext = char(fname);
formatOut = 'yyyymmdd-tHHMMss';
timestmp = datestr(now,formatOut);
dirname = strcat(noext(1:end-4),'_',timestmp);
[status,msg] = mkdir('Analysis\Figures\RadialProfileAnalysis\',dirname);
cd(strcat('Analysis\Figures\RadialProfileAnalysis\',dirname));


finfo = imfinfo(wholepathtreated);
for i = 1:size(finfo,1)
imtreat(:,:,i) = imread(wholepathtreated,i);
imraw(:,:,i) = imread(wholepath,i);
end

%%

outstack = imraw(:,:,1);
for i=2:size(finfo,1)
imshowpair(imraw(:,:,1),imraw(:,:,i),'Scaling','joint');
[optimizer, metric] = imregconfig('multimodal');
outtemp = imregister(imraw(:,:,i),imraw(:,:,1), 'translation', optimizer, metric);
outstack = cat(3,outstack,outtemp-median(median(outtemp)));
end

%%
% 2D Gaussian fit

[x,y] = meshgrid(1:size(imtreat,2),1:size(imtreat,1));
x1 = x(:);
y1 = y(:);
clear zffit outstack3
% 'VariableNames',{'Offset';'Amplitude';'CentroidX';'CentroidY';'AngleOfRotation';'WidthX';'WidthY'}
for i = 1:size(finfo,1)
zn = outstack(:,:,i);
z = zn(:);
ft = fittype( 'a + b*exp(-(((x1-c1)*cosd(t1)+(y1-c2)*sind(t1))/w1)^2-((-(x1-c1)*sind(t1)+(y1-c2)*cosd(t1))/w2)^2)', 'independent', {'x1', 'y1'}, 'dependent', 'z' );
f = fit([x1,y1],z,ft,'StartPoint',[0 1 111 105 1 1 1]);
coefficienttracking(i,:) = coeffvalues(f);
tempconfint = confint(f);
coeffconfintlow(i,:) = tempconfint(1,:);
coeffconfinthigh(i,:) = tempconfint(2,:);
zffit = f.a + (f.b)*exp(-(((x-(f.c1))*cosd(f.t1)+(y-(f.c2))*sind(f.t1))/(f.w1)).^2-((-(x-(f.c1))*sind(f.t1)+(y-(f.c2))*cosd(f.t1))/(f.w2)).^2);
outstack3(:,:,i) = zffit;
end

%%
% median filter of aligned stack - 2D gaussian fit of surface

for i = 1:size(finfo,1)
inputim(:,:,i) = medfilt2(outstack(:,:,i)-outstack3(:,:,i),[3 1]);
end

% can we get a gaussian filtered and LoG filtered stack without using
% imageJ?

clear outstack4
h1 = fspecial('gaussian',3,2);
h2 = fspecial('log',5,2);
for i = 1:size(finfo,1)
outstack4(:,:,i) = imfilter(imfilter(medfilt2(outstack(:,:,i)-outstack3(:,:,i),[5 1]),h1),h2);
end

%% Let's analyze

centercol = 123;
centerrow = 118;

im = imtreat(1:237,1:237,:);
imtru = imraw(1:237,1:237,:);

% define prominence and peak width parameters for radial peak finder
prom = 0;
peakWidth = 3;

for t = 1:size(im,3)

temp = imtru(:,:,t);

clear ccolN crowN ceuxN colendN rowendN pksN locsN wN pN allcoordinatesrowN allcoordinatescolN allcoordinatesconcatN peakcoordinatesconcatN ccolE crowE ceuxE colendE rowendE pksE locsE wE pE allcoordinatesrowE allcoordinatescolE allcoordinatesconcatE peakcoordinatesconcatE ccolS crowS ceuxS colendS rowendS pksS locsS wS pS allcoordinatesrowS allcoordinatescolS allcoordinatesconcatS peakcoordinatesconcatS ccolW crowW ceuxW colendW rowendW pksW locsW wW pW allcoordinatesrowW allcoordinatescolW allcoordinatesconcatW peakcoordinatesconcatW

%quadrant N

for i = 1:size(im,2)
[ccolN{i},crowN{i},ceuxN{i},colendN{i},rowendN{i}]= improfile(im(:,:,t), [centercol i], [centerrow 1]);
[pksN{i},locsN{i},wN{i},pN{i}] = findpeaks(ceuxN{i},'MinPeakProminence',prom,'MinPeakWidth',peakWidth);
allcoordinatesrowN{i}= crowN{i};
allcoordinatescolN{i}= ccolN{i};
alllocsN{i} = locsN{i};
allwN{i} = wN{i};
allcoordinatesconcatN{i}=cat(2,allcoordinatesrowN{i},allcoordinatescolN{i});
peakcoordinatesconcatN{i}=round(allcoordinatesconcatN{i}(locsN{i},:));
peakindsconcatN{i}= sub2ind([size(im,1) size(im,2)],peakcoordinatesconcatN{i}(:,1),peakcoordinatesconcatN{i}(:,2));
A = peakcoordinatesconcatN{i}';
B = peakindsconcatN{i}';
C = temp(B);
distancesN{i} = sqrt((A(1,:)-centerrow).^2 + (A(2,:)-centercol).^2 + (C-imtru(118,123,1)).^2);
clear A B C
end

%quadrant E

for i = 1:size(im,1)
[ccolE{i},crowE{i},ceuxE{i},colendE{i},rowendE{i}]= improfile(im(:,:,t), [centercol size(im,2)], [centerrow i]);
[pksE{i},locsE{i},wE{i},pE{i}] = findpeaks(ceuxE{i},'MinPeakProminence',prom,'MinPeakWidth',peakWidth);
allcoordinatesrowE{i}= crowE{i};
allcoordinatescolE{i}= ccolE{i};
alllocsE{i} = locsE{i};
allwE{i} = wE{i};
allcoordinatesconcatE{i}=cat(2,allcoordinatesrowE{i},allcoordinatescolE{i});
peakcoordinatesconcatE{i}=round(allcoordinatesconcatE{i}(locsE{i},:));
peakindsconcatE{i}= sub2ind([size(im,1) size(im,2)],peakcoordinatesconcatE{i}(:,1),peakcoordinatesconcatE{i}(:,2));
A = peakcoordinatesconcatE{i}';
B = peakindsconcatE{i}';
C = temp(B);
distancesE{i} = sqrt((A(1,:)-centerrow).^2 + (A(2,:)-centercol).^2 + (C-imtru(118,123,1)).^2);
clear A B C
end

%quadrant S

for i = 1:size(im,2)
[ccolS{i},crowS{i},ceuxS{i},colendS{i},rowendS{i}]= improfile(im(:,:,t), [centercol size(im,2)-i+1], [centerrow size(im,1)]);
[pksS{i},locsS{i},wS{i},pS{i}] = findpeaks(ceuxS{i},'MinPeakProminence',prom,'MinPeakWidth',peakWidth);
allcoordinatesrowS{i}= crowS{i};
allcoordinatescolS{i}= ccolS{i};
alllocsS{i} = locsS{i};
allwS{i} = wS{i};
allcoordinatesconcatS{i}=cat(2,allcoordinatesrowS{i},allcoordinatescolS{i});
peakcoordinatesconcatS{i}=round(allcoordinatesconcatS{i}(locsS{i},:));
peakindsconcatS{i}= sub2ind([size(im,1) size(im,2)],peakcoordinatesconcatS{i}(:,1),peakcoordinatesconcatS{i}(:,2));
A = peakcoordinatesconcatS{i}';
B = peakindsconcatS{i}';
C = temp(B);
distancesS{i} = sqrt((A(1,:)-centerrow).^2 + (A(2,:)-centercol).^2 + (C-imtru(118,123,1)).^2);
clear A B C
end

%quadrant W

for i = 1:size(im,1)
[ccolW{i},crowW{i},ceuxW{i},colendW{i},rowendW{i}]= improfile(im(:,:,t), [centercol 1], [centerrow size(im,1)-i+1]);
[pksW{i},locsW{i},wW{i},pW{i}] = findpeaks(ceuxW{i},'MinPeakProminence',prom,'MinPeakWidth',peakWidth);
allcoordinatesrowW{i}= crowW{i};
allcoordinatescolW{i}= ccolW{i};
alllocsW{i} = locsW{i};
allwW{i} = wW{i};
allcoordinatesconcatW{i}=cat(2,allcoordinatesrowW{i},allcoordinatescolW{i});
peakcoordinatesconcatW{i}=round(allcoordinatesconcatW{i}(locsW{i},:));
peakindsconcatW{i}= sub2ind([size(im,1) size(im,2)],peakcoordinatesconcatW{i}(:,1),peakcoordinatesconcatW{i}(:,2));
A = peakcoordinatesconcatW{i}';
B = peakindsconcatW{i}';
C = temp(B);
distancesW{i} = sqrt((A(1,:)-centerrow).^2 + (A(2,:)-centercol).^2 + (C-imtru(118,123,1)).^2);
clear A B C

end

allpeakcoordinates{1,t} = cat(2,peakcoordinatesconcatN,peakcoordinatesconcatE,peakcoordinatesconcatS,peakcoordinatesconcatW);
allpeakcoordinates{2,t} = cat(2,peakindsconcatN,peakindsconcatE,peakindsconcatS,peakindsconcatW);
allpeakdistances{1,t} = cat(2,distancesN,distancesE,distancesS,distancesW);
allpeaklocsalongprofile{1,t} = cat(2,alllocsN,alllocsE,alllocsS,alllocsW);
allpeakwidths{1,t} = cat(2,allwN,allwE,allwS,allwW);

end

xall = [];
yall = [];
zall = [];

tstM = zeros(237,237,145);
for i=1:145
[x,y]=meshgrid(1:237,1:237);
tempM = zeros(237,237);
[revisedpeakinds{i},chinds{i}] = unique(cell2mat(allpeakcoordinates{2,i}'));
tempM(revisedpeakinds{i}) = 1;
temppeakdists = cell2mat(allpeakdistances{1,i});
temppeakwidths = cell2mat(allpeakwidths{1,i}');
revisedpeakdists{i} = temppeakdists(chinds{i})';
revisedpeakwidths{i} = temppeakwidths(chinds{i});
tempMcleske = bwmorph(bwskel(logical(tempM)),'clean');
tempMcleske = tempMcleske.*mask23;
binidx{i} = find(tempMcleske==1);
[~,ia] = setdiff(revisedpeakinds{i},binidx{i})
revisedpeakdists{i}(ia) = [];
revisedpeakwidths{i}(ia) = [];
tempMxtru = tempMcleske .* imtru(:,:,i);
revisedpeakvals{i} = tempMxtru(binidx{i})-(coefficienttracking(i,1)-median(coefficienttracking(:,1)));
tstM(:,:,i)=tempMcleske;
tempM1 = tempMxtru(:);
xx= x(tempM1~=0);
yy= y(tempM1~=0);
zz= tempM1(tempM1~=0);
xall = cat(1,xall,xx);
yall = cat(1,yall,yy);
zall = cat(1,zall,zz);
ds{i} = [xx yy zz];
% scatter3(xx,yy,zz,'k.');
% hold on
clear tempM
end

for i = 1:145
imshow(tstM(:,:,i))
pause(0.1)
end

figure()
imagesc(mean(tstM,3))
daspect([1 1 1])
colorbar
caxis([0 0.5])
print('-dsvg','Probability')

